Diabetes prediction using Multi layer perceptron
